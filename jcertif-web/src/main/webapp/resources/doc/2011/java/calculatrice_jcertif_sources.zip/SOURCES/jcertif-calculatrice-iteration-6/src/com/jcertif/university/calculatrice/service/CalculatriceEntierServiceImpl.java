package com.jcertif.university.calculatrice.service;

import com.jcertif.university.calculatrice.exception.OperateurInconnuException;

/**
 * Service permettant de faire des calculs avec des entiers.
 * 
 * @author rossi.oddet
 * 
 */
public class CalculatriceEntierServiceImpl implements CalculatriceEntierService {

	/**
	 * @param var1
	 *            un entier
	 * @param var2
	 *            un entier
	 * @return le r�sultat de l'addition de deux entiers
	 */
	public int plus(int var1, int var2) {
		return var1 + var2;
	}

	/**
	 * @param var1
	 *            un entier
	 * @param var2
	 *            un entier
	 * @return le r�sultat de la soustraction entre deux entiers
	 */
	public int moins(int var1, int var2) {
		return var1 - var2;
	}

	/**
	 * @param var1
	 *            un entier
	 * @param var2
	 *            un entier
	 * @return le r�sultat de la multiplication entre deux entiers
	 */
	public int multiplier(int var1, int var2) {
		return var1 * var2;
	}

	/**
	 * @param var1
	 *            un entier
	 * @param var2
	 *            un entier
	 * @return le r�sultat de la division entre deux entiers
	 */
	public int diviser(int var1, int var2) {
		return var1 / var2;
	}
	
	/**
	 * 
	 */
	public int evaluerExpression(final String saisie) throws OperateurInconnuException {
		int var1 = 0;
		int var2 = 0;

		if (saisie.contains("+")) {
			// Cas d'une addition
			String[] tab = saisie.split("\\+");
			var1 = Integer.parseInt(tab[0]);
			var2 = Integer.parseInt(tab[1]);
			// Appel de la m�thode plus(int,int) de la classe
			// CalculatriceEntierServiceImpl
			return plus(var1, var2);
		} else if (saisie.contains("-")) {
			// Cas d'une soustraction
			String[] tab = saisie.split("-");
			var1 = Integer.parseInt(tab[0]);
			var2 = Integer.parseInt(tab[1]);
			// Appel de la m�thode moins(int,int) de la classe
			// CalculatriceEntierServiceImpl
			return moins(var1, var2);

		} else if (saisie.contains("*")) {
			// Cas d'une multiplication
			String[] tab = saisie.split("\\*");
			var1 = Integer.parseInt(tab[0]);
			var2 = Integer.parseInt(tab[1]);
			// Appel de la m�thode multiplier(int,int) de la classe
			// CalculatriceEntierServiceImpl
			return multiplier(var1, var2);
		} else if (saisie.contains("/")) {
			// Cas d'une division
			String[] tab = saisie.split("/");
			var1 = Integer.parseInt(tab[0]);
			var2 = Integer.parseInt(tab[1]);
			// Appel de la m�thode diviser(int,int) de la classe
			// CalculatriceEntierServiceImpl
			return diviser(var1, var2);
		} 
		
		throw new OperateurInconnuException();
	}

}
