package com.jcertif.university.calculatrice.service;

/**
 * Interface de calcul pour les entiers.
 * 
 * @author rossi.oddet
 * 
 */
public interface CalculatriceEntierService {

	/**
	 * @param var1
	 *            un entier
	 * @param var2
	 *            un entier
	 * @return le r�sultat de l'addition de deux entiers
	 */
	public int plus(int var1, int var2);

	/**
	 * @param var1
	 *            un entier
	 * @param var2
	 *            un entier
	 * @return le r�sultat de la soustraction entre deux entiers
	 */
	public int moins(int var1, int var2);

	/**
	 * @param var1
	 *            un entier
	 * @param var2
	 *            un entier
	 * @return le r�sultat de la multiplication entre deux entiers
	 */
	public int multiplier(int var1, int var2);

	/**
	 * @param var1
	 *            un entier
	 * @param var2
	 *            un entier
	 * @return le r�sultat de la division entre deux entiers
	 */
	public int diviser(int var1, int var2);
	
	/**
	 * @param saisie une saisie
	 * @return le r�sultat de l'�valuation
	 */
	public int evaluerExpression(String saisie);
}
