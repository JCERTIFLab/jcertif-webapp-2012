package com.jcertif.university.calculatrice.exception;

/**
 * @author rossi.oddet
 *
 */
public class OperateurInconnuException extends Exception{

	private static final long serialVersionUID = 1L;

}
