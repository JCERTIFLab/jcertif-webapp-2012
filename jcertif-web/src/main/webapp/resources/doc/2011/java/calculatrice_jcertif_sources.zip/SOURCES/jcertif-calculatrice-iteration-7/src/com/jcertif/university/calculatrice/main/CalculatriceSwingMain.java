package com.jcertif.university.calculatrice.main;

/**
 * @author rossi.oddet
 *
 */
public class CalculatriceSwingMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
