package com.jcertif.university.calculatrice.service;

/**
 * Service permettant de fire des op�rations sur des entiers et des doubles.
 * 
 * @author rossi.oddet
 * 
 */
public class CalculatriceCompletServiceImpl extends CalculatriceEntierServiceImpl implements
		CalculatriceEntierService {

	/**
	 * @param var1
	 *            un nombre d�cimal
	 * @param var2
	 *            un nombre d�cimal
	 * @return le r�sultat de l'addition de deux nombres d�cimaux
	 */
	public double plus(double var1, double var2) {
		return var1 + var2;
	}

	/**
	 * @param var1
	 *            un nombre d�cimal
	 * @param var2
	 *            un nombre d�cimal
	 * @return le r�sultat de la soustraction de deux nombres d�cimaux
	 */
	public double moins(double var1, double var2) {
		return var1 - var2;
	}

	/**
	 * @param var1
	 *            un nombre d�cimal
	 * @param var2
	 *            un nombre d�cimal
	 * @return le r�sultat de la multiplication de deux nombres d�cimaux
	 */
	public double multiplier(double var1, double var2) {
		return var1 * var2;
	}

	/**
	 * @param var1
	 *            un nombre d�cimal
	 * @param var2
	 *            un nombre d�cimal
	 * @return le r�sultat de la division entre deux nombres d�cimaux
	 */
	public double diviser(double var1, double var2) {
		return var1 / var2;
	}

}
